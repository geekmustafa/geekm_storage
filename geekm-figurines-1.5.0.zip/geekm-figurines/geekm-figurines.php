<?php
/**
 * Plugin Name: Geekm Figurines
 * Description: إدارة مخزون المجسمات المطبوعة + الطلبات الناقصة + قائمة الطباعة + رولات الفلامنت. صفحة /main + برنامج للحاسبة.
 * Version: 1.5.0
 * Author: GeekmStore
 */
if (!defined('ABSPATH')) exit;

define('GEEKMF_VER', '1.5.0');

/* =========================================================
 * الإعدادات
 * ======================================================= */
function geekmf_opts() {
    $d = array(
        'featured_cat' => '',
        'low'          => 3,
        'accent'       => '#007aff',
        'theme'        => 'auto',
        'title'        => 'مخزن المجسمات',
        'stock_mode'   => 0,
        'disc_on'      => 1,
        'disc_price'   => 4,
        'disc_qty'     => 4,
        'disc_amount'  => 1000,
        'disc_label'   => 'خصم العرض (كل 4 قطع بـ 15,000 د.ع)',
    );
    return wp_parse_args(get_option('geekmf_options', array()), $d);
}

register_activation_hook(__FILE__, function () {
    if (!get_option('geekmf_api_key')) {
        update_option('geekmf_api_key', wp_generate_password(32, false, false));
    }
    if (!get_page_by_path('main')) {
        wp_insert_post(array(
            'post_title'   => 'المجسمات',
            'post_name'    => 'main',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '[geekm_figurines]',
        ));
    }
});

/* =========================================================
 * 1. حقل وزن المجسم في صفحة المنتج (نفس الحقل القديم)
 * ======================================================= */
add_action('woocommerce_product_options_general_product_data', function () {
    echo '<div class="options_group">';
    woocommerce_wp_text_input(array(
        'id' => '_model_weight_g', 'label' => 'وزن المجسم (جرام)', 'type' => 'number',
        'custom_attributes' => array('step' => 'any', 'min' => '0'),
    ));
    woocommerce_wp_text_input(array('id' => '_geekm_barcode', 'label' => 'باركود المجسم (اختياري، أو استخدم SKU)'));
    echo '</div>';
});
add_action('woocommerce_process_product_meta', function ($post_id) {
    if (isset($_POST['_model_weight_g'])) {
        update_post_meta($post_id, '_model_weight_g', sanitize_text_field(wp_unslash($_POST['_model_weight_g'])));
    }
    if (isset($_POST['_geekm_barcode'])) {
        update_post_meta($post_id, '_geekm_barcode', sanitize_text_field(wp_unslash($_POST['_geekm_barcode'])));
    }
});

/* =========================================================
 * 2. الحسابات
 * ======================================================= */
function geekmf_pending_map() {
    static $map = null;
    if ($map !== null) return $map;
    $map = array();
    $orders = wc_get_orders(array('status' => array('processing', 'on-hold'), 'limit' => -1, 'return' => 'objects'));
    foreach ($orders as $o) {
        foreach ($o->get_items() as $it) {
            $pid = $it->get_product_id();
            $map[$pid] = (isset($map[$pid]) ? $map[$pid] : 0) + (int) $it->get_quantity();
        }
    }
    return $map;
}

function geekmf_item($p) {
    $o       = geekmf_opts();
    $pm      = geekmf_pending_map();
    $id      = $p->get_id();
    $wc      = (int) $p->get_stock_quantity();
    $pending = isset($pm[$id]) ? (int) $pm[$id] : 0;
    // إذا ووكومرس ينقص المخزون عند الطلب: المتوفر الفعلي = المخزون + الطلبات المعلقة
    $stock    = max(0, $o['stock_mode'] ? $wc + $pending : $wc);
    $in_print = (int) get_post_meta($id, '_geekm_in_print', true);
    $need     = max(0, $pending - $stock - $in_print);

    if ($need > 0)          $st = 'print';
    elseif ($in_print > 0)  $st = 'making';
    elseif ($stock <= 0)    $st = 'out';
    elseif ($stock <= (int) $o['low']) $st = 'low';
    else                    $st = 'ok';

    $img = $p->get_image_id() ? wp_get_attachment_image_url($p->get_image_id(), 'medium') : '';
    if (!$img) $img = wc_placeholder_img_src();

    return array(
        'id'       => $id,
        'title'    => html_entity_decode($p->get_name(), ENT_QUOTES, 'UTF-8'),
        'image'    => $img,
        'stock'    => $stock,
        'pending'  => $pending,
        'in_print' => $in_print,
        'need'     => $need,
        'weight'   => (float) get_post_meta($id, '_model_weight_g', true),
        'sku'      => (string) $p->get_sku(),
        'barcode'  => (string) get_post_meta($id, '_geekm_barcode', true),
        'status'   => $st,
        'cats'     => wp_get_post_terms($id, 'product_cat', array('fields' => 'slugs')),
    );
}

function geekmf_all_items() {
    $out = array();
    $products = wc_get_products(array('limit' => -1, 'status' => 'publish', 'return' => 'objects'));
    foreach ($products as $p) {
        if (!$p->managing_stock()) continue;
        $out[] = geekmf_item($p);
    }
    return $out;
}

/* =========================================================
 * 3. REST API (للصفحة وللبرنامج)
 * ======================================================= */
function geekmf_can($request) {
    if (current_user_can('manage_woocommerce')) return true;
    $key   = $request->get_header('x-geekm-key');
    $saved = get_option('geekmf_api_key');
    return $saved && $key && hash_equals($saved, $key);
}
function geekmf_resp($data, $code = 200) {
    $r = new WP_REST_Response($data, $code);
    $r->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
    return $r;
}

add_action('rest_api_init', function () {
    $ns = 'geekm-fig/v1';
    register_rest_route($ns, '/items', array('methods' => 'GET', 'callback' => 'geekmf_api_items', 'permission_callback' => 'geekmf_can'));
    register_rest_route($ns, '/adjust', array('methods' => 'POST', 'callback' => 'geekmf_api_adjust', 'permission_callback' => 'geekmf_can'));
    register_rest_route($ns, '/scan', array('methods' => 'POST', 'callback' => 'geekmf_api_scan', 'permission_callback' => 'geekmf_can'));
    // v1.3: بحث بالباركود بدون تعديل المخزون + ربط باركود بمنتج (لشاشة الريوتري)
    register_rest_route($ns, '/lookup', array('methods' => 'GET', 'callback' => 'geekmf_api_lookup', 'permission_callback' => 'geekmf_can'));
    register_rest_route($ns, '/link', array('methods' => 'POST', 'callback' => 'geekmf_api_link', 'permission_callback' => 'geekmf_can'));
    // v1.4: احصائيات للريوتري: الطلبات الجديدة + مبيعات اليوم + اكثر 3 منتجات مبيعاً هذا الاسبوع
    register_rest_route($ns, '/stats', array('methods' => 'GET', 'callback' => 'geekmf_api_stats', 'permission_callback' => 'geekmf_can'));
    register_rest_route($ns, '/filament', array('methods' => 'GET', 'callback' => 'geekmf_api_fil_list', 'permission_callback' => 'geekmf_can'));
    register_rest_route($ns, '/filament/adjust', array('methods' => 'POST', 'callback' => 'geekmf_api_fil_adjust', 'permission_callback' => 'geekmf_can'));
    register_rest_route($ns, '/filament/add', array('methods' => 'POST', 'callback' => 'geekmf_api_fil_add', 'permission_callback' => 'geekmf_can'));

    // نفس المسار القديم للرازبيري باي (حتى لا ينكسر شي)
    register_rest_route('geekm/v1', '/missing-prints', array(
        'methods' => 'GET', 'permission_callback' => '__return_true',
        'callback' => function ($request) {
            $cat = $request->get_param('category');
            $items = array();
            foreach (geekmf_all_items() as $i) {
                if ($cat && !in_array($cat, $i['cats'], true)) continue;
                if ($i['need'] > 0) {
                    $items[] = array('title' => $i['title'], 'weight_g' => $i['weight'], 'needed_to_print' => $i['need']);
                }
            }
            return geekmf_resp(array('status' => 'success', 'items' => $items));
        },
    ));
});

/* ---- v1.4: احصائيات (كاش 40 ثانية حتى ما يتأثر الموقع) ---- */
function geekmf_api_stats() {
    $cached = get_transient('geekmf_stats_v2');
    if (is_array($cached)) return geekmf_resp($cached);

    $new  = wc_get_orders(array('status' => array('processing'), 'limit' => -1, 'return' => 'ids'));
    $hold = wc_get_orders(array('status' => array('on-hold'), 'limit' => -1, 'return' => 'ids'));

    $today0    = (new DateTime('today', wp_timezone()))->getTimestamp();
    $week0     = time() - 7 * DAY_IN_SECONDS;
    $orders    = wc_get_orders(array(
        'status'       => array('processing', 'completed', 'on-hold'),
        'date_created' => '>=' . $week0,
        'limit'        => -1,
        'return'       => 'objects',
    ));
    $qty = array();
    $today_orders = 0;
    $today_total  = 0.0;
    foreach ($orders as $o) {
        $ts = $o->get_date_created() ? $o->get_date_created()->getTimestamp() : 0;
        if ($ts >= $today0) {
            $today_orders++;
            $today_total += (float) $o->get_total() - (float) $o->get_total_refunded();
        }
        foreach ($o->get_items() as $it) {
            $pid = (int) $it->get_product_id();
            if (!$pid) continue;
            $qty[$pid] = (isset($qty[$pid]) ? $qty[$pid] : 0) + (int) $it->get_quantity();
        }
    }
    arsort($qty);
    $top = array();
    foreach (array_slice($qty, 0, 3, true) as $pid => $q) {
        $p = wc_get_product($pid);
        if (!$p) continue;
        $img = $p->get_image_id() ? wp_get_attachment_image_url($p->get_image_id(), 'medium') : '';
        $top[] = array('id' => $pid, 'title' => html_entity_decode($p->get_name(), ENT_QUOTES, 'UTF-8'), 'qty' => (int) $q, 'image' => $img ? $img : '');
    }
    /* v1.5: آخر الطلبات المنتظرة (جديد + قيد الانتظار) بتفاصيل بسيطة لشاشة المتر */
    $pending = wc_get_orders(array(
        'status'  => array('processing', 'on-hold'),
        'limit'   => 8,
        'orderby' => 'date',
        'order'   => 'DESC',
        'return'  => 'objects',
    ));
    $olist = array();
    foreach ($pending as $o) {
        $its = array();
        foreach ($o->get_items() as $it) {
            $its[] = array('n' => html_entity_decode($it->get_name(), ENT_QUOTES, 'UTF-8'), 'q' => (int) $it->get_quantity());
        }
        $name = trim($o->get_billing_first_name() . ' ' . $o->get_billing_last_name());
        $olist[] = array(
            'id'     => $o->get_id(),
            'name'   => $name,
            'city'   => (string) $o->get_billing_city(),
            'status' => $o->get_status(),
            'total'  => round((float) $o->get_total()),
            'ts'     => $o->get_date_created() ? $o->get_date_created()->getTimestamp() : 0,
            'items'  => array_slice($its, 0, 3),
            'more'   => max(0, count($its) - 3),
        );
    }
    $data = array(
        'orders'       => $olist,
        'new'          => count($new),
        'hold'         => count($hold),
        'today_orders' => $today_orders,
        'today_total'  => round($today_total),
        'currency'     => html_entity_decode(get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8'),
        'top'          => $top,
        'time'         => current_time('H:i:s'),
    );
    set_transient('geekmf_stats_v2', $data, 40);
    return geekmf_resp($data);
}

function geekmf_api_items() {
    $o = geekmf_opts();
    $items = geekmf_all_items();
    $cats = array();
    $terms = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => true));
    if (!is_wp_error($terms)) {
        foreach ($terms as $t) $cats[] = array('slug' => $t->slug, 'name' => html_entity_decode($t->name, ENT_QUOTES, 'UTF-8'));
    }
    return geekmf_resp(array('items' => $items, 'cats' => $cats, 'featured' => $o['featured_cat'], 'low' => (int) $o['low'], 'time' => current_time('H:i:s')));
}

function geekmf_api_adjust($req) {
    $r = geekmf_do_adjust((int) $req->get_param('product_id'), sanitize_key($req->get_param('action')), (int) $req->get_param('qty'));
    return is_wp_error($r) ? $r : geekmf_resp($r);
}

function geekmf_do_adjust($id, $act, $qty) {
    $qty = max(0, min(1000, (int) $qty));
    $p   = wc_get_product($id);
    if (!$p || !$qty) return new WP_Error('bad', 'بيانات غير صحيحة', array('status' => 400));

    $ip = (int) get_post_meta($id, '_geekm_in_print', true);
    switch ($act) {
        case 'queue':   $ip += $qty; break;                                   // أرسلت للطباعة
        case 'unqueue': $ip = max(0, $ip - $qty); break;                      // إلغاء من قائمة الطباعة
        case 'done':    $ip = max(0, $ip - $qty); wc_update_product_stock($p, $qty, 'increase'); break; // انطبعت
        case 'stock':   wc_update_product_stock($p, $qty, 'increase'); break; // +مخزون مباشر
        case 'remove':  wc_update_product_stock($p, $qty, 'decrease'); break; // -مخزون (تصحيح)
        default: return new WP_Error('bad', 'إجراء غير معروف', array('status' => 400));
    }
    update_post_meta($id, '_geekm_in_print', $ip);
    return geekmf_item(wc_get_product($id));
}

/* ---- المسح بالباركود (للرازبيري باي): كل مسحة = +1 للمخزن ---- */
function geekmf_find_product_id($code) {
    $code = trim($code);
    if ($code === '') return 0;
    $ids = get_posts(array(
        'post_type' => 'product', 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids',
        'meta_query' => array('relation' => 'OR',
            array('key' => '_sku', 'value' => $code),
            array('key' => '_geekm_barcode', 'value' => $code),
            array('key' => '_global_unique_id', 'value' => $code)),
    ));
    return $ids ? (int) $ids[0] : 0;
}

function geekmf_api_scan($req) {
    $code = sanitize_text_field($req->get_param('code'));
    $qty  = max(1, min(100, (int) $req->get_param('qty')));
    $act  = sanitize_key($req->get_param('action'));
    if (!in_array($act, array('done', 'stock', 'remove'), true)) $act = 'stock';
    $id = geekmf_find_product_id($code);
    if (!$id) return geekmf_resp(array('found' => false, 'code' => $code));   // مو مجسم (مثلاً باركود طلب) — يتجاهله
    $r = geekmf_do_adjust($id, $act, $qty);
    if (is_wp_error($r)) return $r;
    return geekmf_resp(array('found' => true, 'id' => $id, 'title' => $r['title'], 'stock' => $r['stock'], 'need' => $r['need'], 'in_print' => $r['in_print']));
}

/* ---- v1.3: بحث فقط (لا يغيّر المخزون) ---- */
function geekmf_api_lookup($req) {
    $code = sanitize_text_field($req->get_param('code'));
    $id = geekmf_find_product_id($code);
    $p = $id ? wc_get_product($id) : null;
    if (!$p) return geekmf_resp(array('found' => false, 'code' => $code));
    return geekmf_resp(array('found' => true, 'code' => $code, 'item' => geekmf_item($p)));
}

/* ---- v1.3: ربط باركود جديد بمنتج (يُحفظ بحقل الباركود _geekm_barcode) ---- */
function geekmf_api_link($req) {
    $id   = (int) $req->get_param('product_id');
    $code = sanitize_text_field($req->get_param('code'));
    $p = $id ? wc_get_product($id) : null;
    if (!$p || $code === '') return new WP_Error('bad', 'بيانات غير صحيحة', array('status' => 400));
    $other = geekmf_find_product_id($code);
    if ($other && $other !== $id) {
        $op = wc_get_product($other);
        return new WP_Error('dup', 'الباركود مربوط مسبقاً بـ: ' . ($op ? $op->get_name() : $other), array('status' => 409));
    }
    update_post_meta($id, '_geekm_barcode', $code);
    return geekmf_resp(array('ok' => true, 'item' => geekmf_item(wc_get_product($id))));
}

/* ---- الفلامنت (نفس الخيار القديم geekm_filament_rolls فتبقى بياناتك) ---- */
function geekmf_rolls_out() {
    $out = array();
    foreach (get_option('geekm_filament_rolls', array()) as $id => $r) {
        $out[] = array('id' => $id, 'name' => $r['name'], 'type' => $r['type'], 'qty' => (int) $r['qty'], 'image' => $r['image']);
    }
    return $out;
}
function geekmf_api_fil_list() { return geekmf_resp(geekmf_rolls_out()); }

function geekmf_api_fil_adjust($req) {
    $rolls = get_option('geekm_filament_rolls', array());
    $id = sanitize_text_field($req->get_param('id'));
    $a  = sanitize_key($req->get_param('action'));
    if (isset($rolls[$id])) {
        if ($a === 'inc') $rolls[$id]['qty']++;
        elseif ($a === 'dec' && $rolls[$id]['qty'] > 0) $rolls[$id]['qty']--;
        elseif ($a === 'delete') unset($rolls[$id]);
        update_option('geekm_filament_rolls', $rolls);
    }
    return geekmf_resp(geekmf_rolls_out());
}

function geekmf_api_fil_add($req) {
    $rolls = get_option('geekm_filament_rolls', array());
    $img = 'https://via.placeholder.com/150?text=No+Image';
    $files = $req->get_file_params();
    if (!empty($files['fImage']['name'])) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $up = wp_handle_upload($files['fImage'], array(
            'test_form' => false,
            'mimes' => array('jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif'),
        ));
        if (!isset($up['error']) && isset($up['url'])) $img = $up['url'];
    }
    $type = sanitize_text_field($req->get_param('fType'));
    if (!in_array($type, array('PLA', 'PETG', 'ABS', 'TPU'), true)) $type = 'PLA';
    $rolls[uniqid('roll_')] = array(
        'name'  => sanitize_text_field($req->get_param('fName')),
        'type'  => $type,
        'qty'   => max(0, (int) $req->get_param('fQty')),
        'image' => $img,
    );
    update_option('geekm_filament_rolls', $rolls);
    return geekmf_resp(geekmf_rolls_out());
}

/* =========================================================
 * 4. الصفحة (شورت كود) — محمية بتسجيل الدخول
 * ======================================================= */
add_shortcode('geekm_figurines', 'geekmf_shortcode');
add_shortcode('geekm_filament', 'geekmf_shortcode');
// أسماء الشورت كود القديمة تشتغل أيضاً
add_shortcode('inventory_manager', 'geekmf_shortcode');
add_shortcode('filament_grid', 'geekmf_shortcode');

function geekmf_shortcode($atts, $content = '', $tag = '') {
    $atts = shortcode_atts(array('category' => ''), $atts);
    if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);

    if (!current_user_can('manage_woocommerce')) {
        return '<div style="direction:rtl;max-width:360px;margin:30px auto;text-align:center"><h3>🔒 صفحة خاصة بالإدارة</h3>'
            . wp_login_form(array('echo' => false, 'redirect' => get_permalink())) . '</div>';
    }
    $o = geekmf_opts();
    $cfg = array(
        'rest'     => untrailingslashit(rest_url('geekm-fig/v1')),
        'nonce'    => wp_create_nonce('wp_rest'),
        'category' => sanitize_title($atts['category']),
        'view'     => in_array($tag, array('geekm_filament', 'filament_grid'), true) ? 'fil' : 'figs',
        'title'    => $o['title'],
    );
    $accent = sanitize_hex_color($o['accent']) ?: '#007aff';
    $theme  = in_array($o['theme'], array('auto', 'light', 'dark'), true) ? $o['theme'] : 'auto';

    return '<style>' . geekmf_css() . '</style>'
        . '<div id="geekmf" class="' . esc_attr($theme) . '" style="--ac:' . esc_attr($accent) . '" data-cfg="' . esc_attr(wp_json_encode($cfg)) . '">جارٍ التحميل…</div>'
        . '<script>' . geekmf_js() . '</script>';
}

// منع الكاش + إخفاء الصفحة عن محركات البحث
add_action('template_redirect', function () {
    global $post;
    $hit = strpos($_SERVER['REQUEST_URI'], '/raw/') !== false;
    if (!$hit && is_singular() && $post) {
        foreach (array('geekm_figurines', 'geekm_filament', 'inventory_manager', 'filament_grid') as $sc) {
            if (has_shortcode($post->post_content, $sc)) { $hit = true; break; }
        }
    }
    if ($hit && !is_admin()) {
        nocache_headers();
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('X-Robots-Tag: noindex, nofollow');
    }
});

/* =========================================================
 * 5. خصم العرض في السلة (قابل للتعديل من الإعدادات)
 * ======================================================= */
add_action('woocommerce_cart_calculate_fees', function ($cart) {
    $o = geekmf_opts();
    if (!$o['disc_on']) return;
    if (is_admin() && !defined('DOING_AJAX')) return;
    $q = 0;
    foreach ($cart->get_cart() as $ci) {
        if (floatval($ci['data']->get_price()) == floatval($o['disc_price'])) $q += $ci['quantity'];
    }
    $sets = floor($q / max(1, (int) $o['disc_qty']));
    if ($sets > 0) $cart->add_fee($o['disc_label'], -$sets * floatval($o['disc_amount']));
}, 20, 1);

/* =========================================================
 * 6. صفحة الإعدادات: WooCommerce ← Geekm Figurines
 * ======================================================= */
add_action('admin_menu', function () {
    add_submenu_page('woocommerce', 'Geekm Figurines', 'Geekm Figurines', 'manage_woocommerce', 'geekm-figurines', 'geekmf_settings_page');
});

function geekmf_settings_page() {
    if (!current_user_can('manage_woocommerce')) return;
    if (isset($_POST['geekmf_save']) && check_admin_referer('geekmf_save')) {
        $p = wp_unslash($_POST);
        update_option('geekmf_options', array(
            'featured_cat' => sanitize_title(isset($p['featured_cat']) ? $p['featured_cat'] : ''),
            'low'          => max(0, (int) $p['low']),
            'accent'       => sanitize_hex_color($p['accent']) ?: '#007aff',
            'theme'        => in_array($p['theme'], array('auto', 'light', 'dark'), true) ? $p['theme'] : 'auto',
            'title'        => sanitize_text_field($p['title']),
            'stock_mode'   => empty($p['stock_mode']) ? 0 : 1,
            'disc_on'      => empty($p['disc_on']) ? 0 : 1,
            'disc_price'   => floatval($p['disc_price']),
            'disc_qty'     => max(1, (int) $p['disc_qty']),
            'disc_amount'  => floatval($p['disc_amount']),
            'disc_label'   => sanitize_text_field($p['disc_label']),
        ));
        if (!empty($p['regen_key'])) update_option('geekmf_api_key', wp_generate_password(32, false, false));
        echo '<div class="updated"><p>تم الحفظ ✅</p></div>';
    }
    $o = geekmf_opts();
    $terms = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
    $page = get_page_by_path('main');
    ?>
    <div class="wrap" style="direction:rtl;text-align:right">
        <h1>Geekm Figurines</h1>
        <p>صفحة الإدارة: <a href="<?php echo esc_url($page ? get_permalink($page) : home_url('/main/')); ?>" target="_blank"><?php echo esc_html($page ? get_permalink($page) : home_url('/main/')); ?></a>
            — الشورت كود: <code>[geekm_figurines]</code> أو <code>[geekm_figurines category="slug"]</code> للفلامنت <code>[geekm_filament]</code></p>
        <form method="post">
            <?php wp_nonce_field('geekmf_save'); ?>
            <table class="form-table">
                <tr><th>عنوان الصفحة</th><td><input name="title" value="<?php echo esc_attr($o['title']); ?>" class="regular-text"></td></tr>
                <tr><th>التصنيف المميز ⭐</th><td><select name="featured_cat">
                    <option value="">— الكل —</option>
                    <?php if (!is_wp_error($terms)) foreach ($terms as $t) echo '<option value="' . esc_attr($t->slug) . '"' . selected($o['featured_cat'], $t->slug, false) . '>' . esc_html($t->name) . '</option>'; ?>
                </select> <span class="description">يظهر أول تبويب ويفتح عليه افتراضياً</span></td></tr>
                <tr><th>لون التصميم</th><td><input type="color" name="accent" value="<?php echo esc_attr($o['accent']); ?>"></td></tr>
                <tr><th>الوضع</th><td><select name="theme">
                    <?php foreach (array('auto' => 'تلقائي', 'light' => 'فاتح', 'dark' => 'داكن') as $k => $v) echo '<option value="' . $k . '"' . selected($o['theme'], $k, false) . '>' . $v . '</option>'; ?>
                </select></td></tr>
                <tr><th>حد "قليل"</th><td><input type="number" name="low" min="0" value="<?php echo (int) $o['low']; ?>"></td></tr>
                <tr><th>طريقة المخزون</th><td><label><input type="checkbox" name="stock_mode" value="1" <?php checked($o['stock_mode'], 1); ?>>
                    ووكومرس ينقص المخزون عند الطلب (فعّلها إذا المخزون عندك يصير سالب أو ينقص مباشرة عند الطلب)</label></td></tr>
                <tr><th>خصم السلة</th><td>
                    <label><input type="checkbox" name="disc_on" value="1" <?php checked($o['disc_on'], 1); ?>> مفعّل</label><br>
                    سعر القطعة المشمولة <input type="number" step="any" name="disc_price" value="<?php echo esc_attr($o['disc_price']); ?>" style="width:90px">
                    كل <input type="number" name="disc_qty" value="<?php echo (int) $o['disc_qty']; ?>" style="width:60px"> قطع
                    خصم <input type="number" step="any" name="disc_amount" value="<?php echo esc_attr($o['disc_amount']); ?>" style="width:90px"><br>
                    النص <input name="disc_label" value="<?php echo esc_attr($o['disc_label']); ?>" class="regular-text">
                </td></tr>
                <tr><th>مفتاح البرنامج (API Key)</th><td><code style="user-select:all"><?php echo esc_html(get_option('geekmf_api_key')); ?></code><br>
                    <label><input type="checkbox" name="regen_key" value="1"> إنشاء مفتاح جديد (البرنامج لازم ينحدّث بالمفتاح)</label><br>
                    <span class="description">رابط الموقع للبرنامج: <?php echo esc_html(home_url()); ?></span></td></tr>
            </table>
            <p><button class="button button-primary" name="geekmf_save" value="1">حفظ</button></p>
        </form>
    </div>
    <?php
}

/* =========================================================
 * 7. التصميم والسكربت
 * ======================================================= */
function geekmf_css() {
    return <<<'CSS'
#geekmf{--ac:#007aff;--bg:#f2f2f7;--cd:#fff;--tx:#1c1c1e;--mu:#6e6e73;--bd:#e5e5ea;direction:rtl;font-family:-apple-system,"Segoe UI",Tahoma,Arial,sans-serif;background:var(--bg);color:var(--tx);padding:16px;border-radius:16px;max-width:1200px;margin:0 auto;box-sizing:border-box}
#geekmf.dark{--bg:#1c1c1e;--cd:#2c2c2e;--tx:#f2f2f7;--mu:#aeaeb2;--bd:#3a3a3c}
@media(prefers-color-scheme:dark){#geekmf.auto{--bg:#1c1c1e;--cd:#2c2c2e;--tx:#f2f2f7;--mu:#aeaeb2;--bd:#3a3a3c}}
#geekmf *{box-sizing:border-box}
#geekmf button{font-family:inherit;cursor:pointer;border:0;border-radius:10px;padding:9px 12px;font-size:.9em;font-weight:600;background:var(--bd);color:var(--tx)}
#geekmf button.pri{background:var(--ac);color:#fff}
#geekmf button.ok{background:#34c759;color:#fff}
#geekmf button.dg{background:#ff3b30;color:#fff}
#geekmf input,#geekmf select{font-family:inherit;padding:9px;border:1px solid var(--bd);border-radius:10px;background:var(--cd);color:var(--tx);font-size:1em}
.gf-head{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
.gf-head h2{margin:0;font-size:1.4em;color:var(--tx)}
.gf-seg button.on,.gf-tabs button.on,.gf-chips button.on{background:var(--ac);color:#fff}
.gf-tabs,.gf-chips,.gf-tools{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}
.gf-chips button{background:var(--cd);border:1px solid var(--bd)}
.gf-chips button.on{border-color:var(--ac)}
.gf-tools input{flex:1;min-width:140px}
.gf-ts{color:var(--mu);font-size:.8em;align-self:center}
.gf-sum{background:var(--cd);border-radius:14px;padding:12px 14px;margin-bottom:10px;display:flex;gap:18px;flex-wrap:wrap;font-size:.95em}
.gf-sum b{font-size:1.15em}
.gf-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px}
.gf-card{background:var(--cd);border-radius:16px;padding:12px;box-shadow:0 2px 10px rgba(0,0,0,.06);text-align:center;border-top:4px solid var(--bd)}
.gf-card.st-print{border-top-color:#ff3b30}.gf-card.st-making{border-top-color:#007aff}.gf-card.st-out{border-top-color:#8e8e93}.gf-card.st-low{border-top-color:#ff9500}.gf-card.st-ok{border-top-color:#34c759}
.gf-card img{width:100%;height:130px;object-fit:cover;border-radius:10px;background:var(--bd)}
.gf-card h3{margin:8px 0 4px;font-size:1em;color:var(--tx);line-height:1.3}
.gf-b{display:inline-block;padding:3px 10px;border-radius:12px;font-size:.8em;font-weight:700;color:#fff;background:var(--mu)}
.b-print{background:#ff3b30}.b-making{background:#007aff}.b-out{background:#8e8e93}.b-low{background:#ff9500}.b-ok{background:#34c759}
.gf-st{display:flex;justify-content:space-around;margin:10px 0}
.gf-st b{display:block;font-size:1.3em}.gf-st small{color:var(--mu);font-size:.75em}
.gf-act{display:flex;gap:5px;align-items:center}
.gf-act input{width:56px;text-align:center;padding:7px 4px}
.gf-act button{flex:1;padding:8px 4px;font-size:.82em}
.gf-mini{display:flex;gap:5px;margin-top:6px}
.gf-mini button{flex:1;font-size:.75em;padding:6px 2px;background:transparent;border:1px solid var(--bd);font-weight:500;color:var(--mu)}
.gf-empty{grid-column:1/-1;text-align:center;color:var(--mu);padding:30px}
#gf-msg{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:10px 18px;border-radius:12px;display:none;z-index:99999}
.gf-modal{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:9999;display:flex;justify-content:center;align-items:center}
.gf-mc{background:var(--cd);padding:22px;border-radius:18px;width:90%;max-width:380px;color:var(--tx)}
.gf-mc label{display:block;margin:10px 0 4px;font-weight:700}.gf-mc input,.gf-mc select{width:100%}
.gf-mc .row{display:flex;gap:8px;margin-top:16px}.gf-mc .row button{flex:1}
CSS;
}

function geekmf_js() {
    return <<<'JS'
(function(){
var root=document.getElementById('geekmf');if(!root)return;
var C=JSON.parse(root.getAttribute('data-cfg'));
var S={items:[],cats:[],featured:'',rolls:null,tab:C.category||'__f',flt:'all',q:'',view:C.view,qty:{},ts:''};
var LBL={print:'⚠️ اطبع',making:'🖨️ قيد الطباعة',out:'نفد',low:'قليل',ok:'✅ متوفر'};
var ORDER={print:0,making:1,out:2,low:3,ok:4};
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function toast(t){var m=document.getElementById('gf-msg');m.textContent=t;m.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(function(){m.style.display='none';},2500);}
function api(path,opt){opt=opt||{};opt.headers=Object.assign({'X-WP-Nonce':C.nonce},opt.headers||{});opt.credentials='same-origin';
 return fetch(C.rest+path,opt).then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.message||'خطأ');return j;});});}
function post(path,obj){return api(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)});}
function curCat(){return S.tab==='__f'?S.featured:(S.tab==='__all'?'':S.tab);}

root.innerHTML='<div class="gf-head"><h2>'+esc(C.title)+'</h2><div class="gf-seg"><button data-view="figs">المجسمات</button> <button data-view="fil">الفلامنت</button></div></div>'
+'<div id="gf-figs"><div class="gf-tabs" id="gf-tabs"></div><div class="gf-sum" id="gf-sum"></div><div class="gf-chips" id="gf-chips"></div>'
+'<div class="gf-tools"><input id="gf-q" type="search" placeholder="🔍 بحث عن مجسم..."><button data-act="reload">⟳ تحديث</button><span class="gf-ts" id="gf-ts"></span></div>'
+'<div class="gf-grid" id="gf-list"></div></div><div id="gf-fil" style="display:none"></div><div id="gf-msg"></div>';

function shown(){var c=curCat();return S.items.filter(function(i){return !c||i.cats.indexOf(c)>-1;});}
function drawTop(){
 var tabs='';if(S.featured){var fc=S.cats.filter(function(c){return c.slug===S.featured})[0];tabs+='<button data-tab="__f" class="'+(S.tab==='__f'?'on':'')+'">⭐ '+esc(fc?fc.name:'المميز')+'</button>';}
 tabs+='<button data-tab="__all" class="'+(S.tab==='__all'?'on':'')+'">الكل</button>';
 S.cats.forEach(function(c){if(c.slug===S.featured)return;tabs+='<button data-tab="'+esc(c.slug)+'" class="'+(S.tab===c.slug?'on':'')+'">'+esc(c.name)+'</button>';});
 document.getElementById('gf-tabs').innerHTML=tabs;
 var it=shown(),n=0,g=0,mk=0,out=0,cnt={all:it.length,print:0,making:0,out:0,low:0,ok:0};
 it.forEach(function(i){cnt[i.status]++;n+=i.need;g+=i.need*i.weight;mk+=i.in_print;});
 document.getElementById('gf-sum').innerHTML='<div>يحتاج طباعة: <b>'+n+'</b> قطعة'+(g?' (≈ '+(g/1000).toFixed(2)+' كغم فلامنت)':'')+'</div><div>نافد: <b>'+cnt.out+'</b></div>';
 var F=[['all','الكل'],['print','⚠️ ناقص'],['out','نفد'],['low','قليل'],['ok','متوفر']],h='';
 F.forEach(function(f){h+='<button data-flt="'+f[0]+'" class="'+(S.flt===f[0]?'on':'')+'">'+f[1]+' ('+cnt[f[0]]+')</button>';});
 document.getElementById('gf-chips').innerHTML=h;
 document.getElementById('gf-ts').textContent=S.ts?('آخر تحديث '+S.ts):'';
}
function drawList(){
 var q=S.q.toLowerCase();
 var it=shown().filter(function(i){return (S.flt==='all'||i.status===S.flt)&&(!q||i.title.toLowerCase().indexOf(q)>-1);});
 it.sort(function(a,b){return ORDER[a.status]-ORDER[b.status]||b.need-a.need||a.title.localeCompare(b.title);});
 var h='';
 it.forEach(function(i){
  var dq=S.qty[i.id]||(i.need>0?i.need:1);
  h+='<div class="gf-card st-'+i.status+'"><img loading="lazy" src="'+esc(i.image)+'" alt=""><h3>'+esc(i.title)+'</h3>'
  +'<span class="gf-b b-'+i.status+'">'+LBL[i.status]+(i.status==='print'?' '+i.need:'')+'</span>'
  +'<div class="gf-st"><div><b>'+i.stock+'</b><small>متوفر</small></div><div><b>'+i.pending+'</b><small>طلبات</small></div></div>'
  +(i.need>0?'<button class="dg" style="width:100%;margin-bottom:6px;font-size:1em;padding:11px" data-act="need" data-id="'+i.id+'" data-n="'+i.need+'">⚡ أضف الناقص +'+i.need+'</button>':'')
  +'<div class="gf-act"><input type="number" min="1" data-q="'+i.id+'" value="'+dq+'"><button class="ok" data-act="add" data-id="'+i.id+'">➕ إضافة</button></div>'
  +'<div class="gf-mini"><button data-act="minus" data-id="'+i.id+'">−1</button><button data-act="plus" data-id="'+i.id+'">+1</button></div></div>';
 });
 document.getElementById('gf-list').innerHTML=h||'<div class="gf-empty">لا توجد مجسمات</div>';
}
function draw(){drawTop();drawList();}
function load(){return api('/items').then(function(d){S.items=d.items;S.cats=d.cats;S.featured=d.featured;S.ts=d.time;
 if(S.tab==='__f'&&!S.featured)S.tab='__all';draw();}).catch(function(e){toast('⚠️ '+e.message);});}

function drawFil(){
 var h='<div class="gf-grid">';
 (S.rolls||[]).forEach(function(r){h+='<div class="gf-card"><img src="'+esc(r.image)+'" alt=""><h3>'+esc(r.name)+'</h3><span class="gf-b">'+esc(r.type)+'</span>'
  +'<div class="gf-act" style="margin:10px 0"><button data-fa="dec" data-id="'+esc(r.id)+'">−</button><b style="flex:1;font-size:1.3em">'+r.qty+'</b><button data-fa="inc" data-id="'+esc(r.id)+'">+</button></div>'
  +'<button class="dg" style="width:100%" data-fa="delete" data-id="'+esc(r.id)+'">حذف</button></div>';});
 if(!(S.rolls||[]).length)h+='<div class="gf-empty">لا توجد رولات مضافة</div>';
 h+='</div><p style="text-align:center"><button class="pri" data-act="addroll" style="padding:12px 26px;border-radius:24px">+ إضافة رولة جديدة</button></p>';
 document.getElementById('gf-fil').innerHTML=h;
}
function loadFil(){return api('/filament').then(function(d){S.rolls=d;drawFil();}).catch(function(e){toast('⚠️ '+e.message);});}
function setView(v){S.view=v;document.getElementById('gf-figs').style.display=v==='figs'?'':'none';document.getElementById('gf-fil').style.display=v==='fil'?'':'none';
 [].forEach.call(root.querySelectorAll('[data-view]'),function(b){b.className=b.getAttribute('data-view')===v?'on':'';});
 if(v==='fil'&&!S.rolls)loadFil();}

function addRollModal(){
 var d=document.createElement('div');d.className='gf-modal';
 d.innerHTML='<div class="gf-mc"><h3 style="margin:0">إضافة رولة جديدة</h3><form><label>اللون / الوصف</label><input name="fName" required>'
 +'<label>النوع</label><select name="fType"><option>PLA</option><option>PETG</option><option>ABS</option><option>TPU</option></select>'
 +'<label>الكمية</label><input type="number" name="fQty" value="1" min="1" required><label>صورة الرولة</label><input type="file" name="fImage" accept="image/*">'
 +'<div class="row"><button type="button" data-x="1">إلغاء</button><button class="pri" type="submit">حفظ</button></div></form></div>';
 root.appendChild(d);
 d.querySelector('[data-x]').onclick=function(){d.remove();};
 d.querySelector('form').onsubmit=function(e){e.preventDefault();
  api('/filament/add',{method:'POST',body:new FormData(e.target)}).then(function(r){S.rolls=r;drawFil();d.remove();toast('تمت الإضافة ✅');}).catch(function(x){toast('⚠️ '+x.message);});};
}

root.addEventListener('click',function(e){
 var b=e.target.closest('button');if(!b)return;
 var v=b.getAttribute('data-view'),t=b.getAttribute('data-tab'),f=b.getAttribute('data-flt'),a=b.getAttribute('data-act'),fa=b.getAttribute('data-fa'),id=b.getAttribute('data-id');
 if(v)return setView(v);
 if(t){S.tab=t;return draw();}
 if(f){S.flt=f;return draw();}
 if(fa){if(fa==='delete'&&!confirm('هل أنت متأكد؟'))return;
  return post('/filament/adjust',{id:id,action:fa}).then(function(r){S.rolls=r;drawFil();}).catch(function(x){toast('⚠️ '+x.message);});}
 if(a==='reload'){load();if(S.view==='fil')loadFil();return;}
 if(a==='addroll')return addRollModal();
 if(a&&id){
  var inp=root.querySelector('[data-q="'+id+'"]'),n=(a==='plus'||a==='minus')?1:(a==='need'?parseInt(b.getAttribute('data-n'),10):(parseInt(inp.value,10)||1));
  var map={add:'stock',need:'stock',plus:'stock',minus:'remove'};
  b.disabled=true;
  post('/adjust',{product_id:parseInt(id,10),action:map[a],qty:n}).then(function(it){
   S.items=S.items.map(function(x){return x.id===it.id?it:x;});delete S.qty[it.id];draw();
   toast({add:'تمت الإضافة ✅',need:'تمت إضافة الناقص ✅',plus:'+1',minus:'-1'}[a]);
  }).catch(function(x){b.disabled=false;toast('⚠️ '+x.message);});
 }
});
root.addEventListener('input',function(e){
 if(e.target.id==='gf-q'){S.q=e.target.value;drawList();}
 else if(e.target.hasAttribute('data-q')){S.qty[e.target.getAttribute('data-q')]=e.target.value;}
});
setView(S.view);load();
setInterval(function(){if(document.hidden||root.contains(document.activeElement)&&document.activeElement.tagName==='INPUT')return;load();},30000);
})();
JS;
}
