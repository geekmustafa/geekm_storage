/*
  knob_terminal_md80et.ino  -  شاشة UEDX48480021-MD80ET (2.1 انش، 480x480 RGB) كطرفية للرازبيري باي   (v3.2)

  v3: صورة 480x480 كاملة (بدون حدود سودة)، ورسم الأجزاء المتغيرة فقط (يزيل الرمش)، ودعم وضع الجرد.
  (v2) رقم التغيير (+2 / -5) والسطر الصغير "60 > 62" تُرسم محلياً على الشاشة نفسها، فالويل يتجاوب فوراً بدون ما ينتظر الرازبيري.
  الرازبيري يستلم القيمة بالخلفية، وعند الضغط على الحفظ يظهر ✓ فوراً والرازبيري يكمل الحفظ مع الموقع.
  الشبكة تشتغل بمهمة (Task) منفصلة عن الويل واللمس، فما يتأثرون ببطء الواي فاي.

  المكتبات المطلوبة (نفس اللي ثبّتناها لمثال الشركة):
    - ESP32_Display_Panel + esp-lib-utils + ESP32_IO_Expander   (مكتبات الشركة، بمجلد libraries)
    - JPEGDEC  (Larry Bank / bitbank2)
  ملفات libraries\ لازم تكون: esp_panel_board_supported_conf.h (MD80ET مفعّل)، esp_panel_drivers_conf.h، esp_utils_conf.h
  اللوحة: ESP32S3 Dev Module | Flash 16MB | PSRAM: OPI PSRAM | Partition: Huge APP | USB CDC On Boot: Enabled
  ملاحظة: لازم تحدّث سكربت الرازبيري (geekm_knob.py v1.5) مع هذا السكتش.
*/
#include <Arduino.h>
#include <math.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <JPEGDEC.h>
#include <esp_display_panel.hpp>

using namespace esp_panel::drivers;
using namespace esp_panel::board;

// ============================================================ الاعدادات - عدّل هذا القسم فقط
#define WIFI_SSID   "GeekM Router"
#define WIFI_PASS   "WIFI_PASSWORD"                       // <-- اكتب باسورد الواي فاي
#define PI_HOST     "192.168.1.109"
#define PI_PORT     8787
#define KNOB_TOKEN  "80792c23e259d6cbcad79b82"

#define PIN_ENC_A   6
#define PIN_ENC_B   5
#define PIN_BTN     0

#define LCD_W 480
#define LCD_H 480
#define FRAME 480                      // حجم الصورة اللي يرسمها الرازبيري (كامل الشاشة)
#define FRAME_OFF 0
#define LAYOUT_OFF 7                   // التصميم 466 داخل الصورة 480: احداثيات اللمس والأرقام نضيف/نطرح 7
#define LW 466
#define OX(x) ((x) + LAYOUT_OFF)

#define ENC_STEPS_PER_DETENT 2         // خطوات الويل لكل طقة. اذا صار يعد مرتين خليها 4
#define ENC_INVERT           1         // 1 = معكوس. رجّعه 0 اذا صار الاتجاه غلط
#define COLOR_SWAP           0         // اذا الألوان مقلوبة (أحمر<->أزرق او ألوان غريبة) غيّرها لـ 1
#define TOUCH_SWAP_XY 0
#define TOUCH_FLIP_X  0
#define TOUCH_FLIP_Y  0
#define POLL_MS       250              // استعلام الرازبيري وقت الخمول
#define LONG_PRESS_MS 700
#define SAVE_FEEDBACK_MS 3000          // اقصى مدة لعلامة ✓ اذا الرازبيري ما رد
#define DEBUG_SERIAL  0                // 1 = يطبع بالسيريال. غيّره لـ 0 بعد ما يشتغل كل شي
#define DEBUG_COLOR_TEST 0             // 1 = أحمر ثم أخضر ثم أزرق ثم أبيض عند التشغيل
// ============================================================

#if DEBUG_SERIAL
#define DBG(...) Serial.printf(__VA_ARGS__)
#else
#define DBG(...)
#endif

#include "overlay.h"   // رسم الأرقام محلياً (لازم يكون بنفس مجلد السكتش)
#include "splash.h"            // شعار شاشة البدء (لازم يكون بنفس مجلد السكتش)

static Board *board = nullptr;
static LCD *lcd = nullptr;
static Touch *tp = nullptr;
static JPEGDEC jpeg;
static uint8_t *jpgBuf = nullptr;
static const size_t JPG_MAX = 220 * 1024;

static uint16_t *frameBuf = nullptr;     // نسخة مما هو معروض الآن على الشاشة (PSRAM)
static uint16_t *decBuf = nullptr;       // الصورة الجديدة المفكوكة (نقارنها مع frameBuf ونرسم الفروقات فقط)
static bool frameValid = false;          // false = لازم رسم كامل
static bool needClear = false;           // true = ننظف الشاشة سوداء قبل أول صورة
static SemaphoreHandle_t fbMux = nullptr; // يحمي frameBuf ورسم الشاشة (مهمة الشبكة + الحلقة الرئيسية)
static portMUX_TYPE stMux = portMUX_INITIALIZER_UNLOCKED;
#define ENTER() portENTER_CRITICAL(&stMux)
#define LEAVE() portEXIT_CRITICAL(&stMux)

// حالة الشاشة (من الرازبيري) + الكمية المحلية
enum { M_NONE = 0, M_PRODUCT = 1, M_OTHER = 2 };
static volatile int curMode = M_NONE;
static volatile int curStock = 0;
static volatile bool curCnt = false;    // وضع الجرد
static volatile int curBase = 0;        // بوضع الجرد: المخزن الحالي (العدد الفعلي = المخزن + التغيير)
static volatile int localDelta = 0;      // التغيير الحالي (المرجع هو الشاشة)
static volatile bool qDirty = false;     // true = فيه تغيير محلي ما وصل للرازبيري بعد
static volatile uint32_t qSeq = 0;
static volatile bool saving = false;     // true = ضغطت حفظ: نعرض ✓
static volatile uint32_t savingT = 0;
static volatile bool ovDirty = false;    // true = لازم نعيد رسم الأرقام
static bool patchesValid = false;
static uint16_t *clean1 = nullptr, *clean2 = nullptr, *ov1 = nullptr, *ov2 = nullptr;

static int drawCB(JPEGDRAW *p) {
  for (int r = 0; r < p->iHeight; r++) {
    int y = p->y + r;
    if (y < 0 || y >= FRAME) continue;
    int x = p->x, w = p->iWidth;
    if (x < 0 || x >= FRAME) continue;
    if (x + w > FRAME) w = FRAME - x;
    memcpy(decBuf + (size_t)y * FRAME + x, p->pPixels + (size_t)r * p->iWidth, (size_t)w * 2);
  }
  return 1;
}

// تعبئة الشاشة بلون واحد (RGB565)
static void fillScreen(uint16_t color) {
  static uint16_t *strip = nullptr;
  const int rows = 10;
  if (!strip) strip = (uint16_t *)heap_caps_malloc(LCD_W * rows * 2, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if (!strip) return;
  for (int i = 0; i < LCD_W * rows; i++) strip[i] = color;
  for (int y = 0; y < LCD_H; y += rows) lcd->drawBitmap(0, y, LCD_W, rows, (const uint8_t *)strip);
}
#define C_BLACK 0x0000
#define C_WHITE 0xFFFF
#define C_RED   0xF800
#define C_GREEN 0x07E0
#define C_BLUE  0x001F

// رسالة حالة: لون + سيريال (الرازبيري يرسم كل النصوص)
static void say(const char *msg, uint16_t color) {
  Serial.printf("[SCREEN] %s\n", msg);
  if (fbMux) xSemaphoreTake(fbMux, portMAX_DELAY);
  fillScreen(color);
  needClear = true;
  frameValid = false;
  patchesValid = false;
  if (fbMux) xSemaphoreGive(fbMux);
}

// ---- مزامنة الرسم مع نهاية اطار الشاشة (يقلل الخطوط/التمزق)
static SemaphoreHandle_t vsyncSem = nullptr;
static bool vsyncOk = false;
static bool IRAM_ATTR onFrameEnd(void *) {
  BaseType_t w = pdFALSE;
  if (vsyncSem) xSemaphoreGiveFromISR(vsyncSem, &w);
  return w == pdTRUE;
}
static void waitFrameEnd() {
  if (!vsyncOk) return;
  xSemaphoreTake(vsyncSem, 0);
  if (xSemaphoreTake(vsyncSem, pdMS_TO_TICKS(80)) != pdTRUE) vsyncOk = false;   // ما اشتغل: نوقف المزامنة
}
// يدفع صفوف من frameBuf للشاشة على دفعات (96 صف) كل دفعة بعد نهاية اطار، من الأعلى للأسفل
static void pushRows(int y0, int h) {
  for (int c = 0; c < h; c += 96) {
    int ch = (h - c < 96) ? (h - c) : 96;
    waitFrameEnd();
    lcd->drawBitmap(FRAME_OFF, FRAME_OFF + y0 + c, FRAME, ch, (const uint8_t *)(frameBuf + (size_t)(y0 + c) * FRAME));
    if (h > 96) vTaskDelay(1);
  }
}

// يرسم فقط الصفوف اللي تغيّرت بين decBuf (الجديدة) و frameBuf (المعروضة) => بدون رمش
static void drawDiff() {
  if (!frameValid) {
    memcpy(frameBuf, decBuf, (size_t)FRAME * FRAME * 2);
    pushRows(0, FRAME);
    frameValid = true;
    return;
  }
  const size_t rowB = (size_t)FRAME * 2;
  int y = 0;
  while (y < FRAME) {
    if (!memcmp(decBuf + (size_t)y * FRAME, frameBuf + (size_t)y * FRAME, rowB)) { y++; continue; }
    int y0 = y, last = y, gap = 0;
    y++;
    while (y < FRAME && gap <= 6) {
      if (memcmp(decBuf + (size_t)y * FRAME, frameBuf + (size_t)y * FRAME, rowB)) { last = y; gap = 0; } else gap++;
      y++;
    }
    int h = last - y0 + 1;
    memcpy(frameBuf + (size_t)y0 * FRAME, decBuf + (size_t)y0 * FRAME, (size_t)h * rowB);
    pushRows(y0, h);
    y = last + 1;
  }
}

// شاشة البدء: دائرة بلون المتجر + الشعار الأبيض (تنرسم فوراً من الفلاش قبل الواي فاي)
static void drawSplash(uint16_t *buf) {
  const float R = FRAME / 2.0f, C = R;
  const int lx0 = (FRAME - SPL_W) / 2, ly0 = (FRAME - SPL_H) / 2;
  const uint8_t br = 76, bg = 168, bb = 193;     // لون المتجر
  const uint8_t rr = 164, rg = 211, rb = 223;    // حلقة خفيفة على الحافة
  for (int y = 0; y < FRAME; y++) {
    float dy = y + 0.5f - C;
    for (int x = 0; x < FRAME; x++) {
      float dx = x + 0.5f - C;
      float r = sqrtf(dx * dx + dy * dy);
      float cov = R - r + 0.5f;
      if (cov <= 0) { buf[(size_t)y * FRAME + x] = 0; continue; }
      if (cov > 1) cov = 1;
      float pr = br, pg = bg, pb = bb;
      if (r > R - 5.0f) { pr = rr; pg = rg; pb = rb; }
      int lx = x - lx0, ly = y - ly0;
      if (lx >= 0 && lx < SPL_W && ly >= 0 && ly < SPL_H) {
        int idx = ly * SPL_W + lx;
        uint8_t b = pgm_read_byte(&splashA[idx >> 1]);
        int a = (idx & 1) ? (b & 0x0F) : (b >> 4);
        float k = a / 15.0f;
        pr += (255 - pr) * k; pg += (255 - pg) * k; pb += (255 - pb) * k;
      }
      pr *= cov; pg *= cov; pb *= cov;
      buf[(size_t)y * FRAME + x] = wr565(rgb565((uint8_t)pr, (uint8_t)pg, (uint8_t)pb));
    }
  }
}

// ---------------------------------------------------------------- الاعادة رسم الأرقام فقط (فوري)
static void overlayRedraw() {
  if (curMode != M_PRODUCT || !patchesValid) return;
  if (xSemaphoreTake(fbMux, pdMS_TO_TICKS(300)) != pdTRUE) { ovDirty = true; return; }
  int dlt = localDelta, stock = curStock;
  bool sv = saving;
  composeR1(ov1, clean1, dlt, sv, curCnt, curBase);
  composeR2(ov2, clean2, stock, dlt, sv);
  pasteRegion(frameBuf, FRAME, ov1, OX(R1_X), OX(R1_Y), R1_W, R1_H);
  pasteRegion(frameBuf, FRAME, ov2, OX(R2_X), OX(R2_Y), R2_W, R2_H);
  lcd->drawBitmap(FRAME_OFF + OX(R1_X), FRAME_OFF + OX(R1_Y), R1_W, R1_H, (const uint8_t *)ov1);
  lcd->drawBitmap(FRAME_OFF + OX(R2_X), FRAME_OFF + OX(R2_Y), R2_W, R2_H, (const uint8_t *)ov2);
  xSemaphoreGive(fbMux);
}

// ---------------------------------------------------------------- الويل
static volatile int32_t encPos = 0;
static volatile uint8_t encState = 0;
static int32_t encTaken = 0;
static const int8_t ENC_TABLE[16] = {0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0};

void IRAM_ATTR encISR() {
  uint8_t s = (digitalRead(PIN_ENC_A) << 1) | digitalRead(PIN_ENC_B);
  encState = ((encState << 2) | s) & 0x0F;
  encPos += ENC_TABLE[encState];
}

static int takeEncoder() {
  int32_t pos = encPos;
  int32_t n = (pos - encTaken) / ENC_STEPS_PER_DETENT;
  encTaken += n * ENC_STEPS_PER_DETENT;
#if ENC_INVERT
  n = -n;
#endif
  return (int)n;
}

// ---------------------------------------------------------------- مدخلات تنتظر الارسال للرازبيري (تكتبها الحلقة الرئيسية وتقرأها مهمة الشبكة)
static volatile int pendingD = 0;        // لفّات الويل (للقوائم والشاشة الرئيسية)
static volatile int pendingBtn = 0;      // 1 قصيرة، 2 طويلة
static volatile int pendingTx = -1, pendingTy = -1;

// تغيير الكمية محلياً (شاشة المنتج)
static void changeDelta(int n) {
  if (curMode != M_PRODUCT || saving) return;
  int v = localDelta + n;
  if (v > 999) v = 999;
  if (v < -999) v = -999;
  if (v == localDelta) return;
  ENTER(); localDelta = v; qDirty = true; qSeq++; ovDirty = true; LEAVE();
}

static void startSaving() {
  if (curMode != M_PRODUCT || saving || localDelta == 0) return;
  savingT = millis(); saving = true; ovDirty = true;
}

static void onTurn(int d) {
  if (curMode == M_PRODUCT) { changeDelta(d); return; }
  ENTER(); pendingD += d; LEAVE();
}

// ---------------------------------------------------------------- زر الضغط
static bool btnDown = false, longSent = false;
static uint32_t btnT = 0;

static void updateButton() {
  bool down = digitalRead(PIN_BTN) == LOW;
  uint32_t now = millis();
  if (down && !btnDown) { btnDown = true; longSent = false; btnT = now; DBG("[BTN] down\n"); }
  else if (down && btnDown && !longSent && now - btnT >= LONG_PRESS_MS) {
    ENTER(); pendingBtn = 2; LEAVE(); longSent = true; DBG("[BTN] LONG press\n");
  } else if (!down && btnDown) {
    btnDown = false;
    DBG("[BTN] up\n");
    if (!longSent && now - btnT > 30) {
      startSaving();                         // ✓ فوري اذا شاشة منتج وفيه تغيير
      ENTER(); pendingBtn = 1; LEAVE();
      DBG("[BTN] SHORT press\n");
    }
  }
}

// ---------------------------------------------------------------- اللمس (CST816S عبر مكتبة الشركة)
static bool touching = false;
static int lastX = 0, lastY = 0;
static uint32_t touchT = 0, lastTouchPoll = 0;

// قراءة اللمس بمهمة (Task) منفصلة: لو شريحة اللمس بطيئة او فيها خطأ I2C ما توقف الويل والشبكة
static volatile int tpN = 0, tpX = 0, tpY = 0;
static void touchTask(void *) {
  TouchPoint pt;
  for (;;) {
    int n = tp->readPoints(&pt, 1, 0);
    if (n > 0) { tpX = pt.x; tpY = pt.y; tpN = 1; vTaskDelay(pdMS_TO_TICKS(15)); }
    else if (n == 0) { tpN = 0; vTaskDelay(pdMS_TO_TICKS(15)); }
    else { tpN = 0; vTaskDelay(pdMS_TO_TICKS(300)); }   // خطأ I2C: لا نكرر بسرعة
  }
}

static void onTap(int x, int y) {
  if (curMode == M_PRODUCT && !saving) {      // نفس مناطق الرازبيري: أزرار +/- محلية، الباقي يروح للرازبيري
    if (y >= 215 && y <= 335 && x < 150) { changeDelta(-1); return; }
    if (y >= 215 && y <= 335 && x > 316) { changeDelta(+1); return; }
    if (y > 335 && x >= LW / 2) startSaving();
  }
  ENTER(); pendingTx = x; pendingTy = y; LEAVE();
}

static void updateTouch() {
  if (!tp) return;
  uint32_t now = millis();
  if (now - lastTouchPoll < 20) return;
  lastTouchPoll = now;
  int n = tpN;
  if (n > 0) {
    int x = tpX, y = tpY;
#if TOUCH_SWAP_XY
    int t = x; x = y; y = t;
#endif
#if TOUCH_FLIP_X
    x = LCD_W - 1 - x;
#endif
#if TOUCH_FLIP_Y
    y = LCD_H - 1 - y;
#endif
    lastX = constrain(x - LAYOUT_OFF, 0, LW - 1);
    lastY = constrain(y - LAYOUT_OFF, 0, LW - 1);
    if (!touching) { touching = true; touchT = now; DBG("[TOUCH] down raw=(%d,%d) -> x=%d y=%d\n", x, y, lastX, lastY); }
  } else if (touching) {
    touching = false;
    if (now - touchT < 700) { DBG("[TOUCH] TAP x=%d y=%d\n", lastX, lastY); onTap(lastX, lastY); }
  }
}

// ---------------------------------------------------------------- الشبكة (مهمة منفصلة)
static HTTPClient http;
static WiFiClient client;
static int frameVer = -1;
static uint32_t lastOk = 0;
static bool offlineShown = false;

static void wifiConnect() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000) delay(200);
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("[WIFI] ip=%s\n", WiFi.localIP().toString().c_str());
  } else {
    say("WiFi FAILED - check SSID/password", C_RED);
  }
}

// نقرأ حالة الرازبيري من الهيدرات (X-Mode / X-Delta / X-Stock) ونطبّقها
static void applyState(int sentQ, uint32_t sentSeq, bool sentDirty) {
  String hm = http.header("X-Mode");
  int mode = hm.length() ? (hm == "product" ? M_PRODUCT : M_OTHER) : M_OTHER;
  int hd = http.header("X-Delta").toInt();
  int hs = http.header("X-Stock").toInt();
  int hc = http.header("X-Cnt").toInt();
  int hb = http.header("X-Base").toInt();
  ENTER();
  if (sentDirty && qSeq == sentSeq) qDirty = false;       // وصلت آخر قيمة للرازبيري
  curMode = mode;
  if (mode == M_PRODUCT) {
    curStock = hs;
    curCnt = hc != 0;
    curBase = hb;
    if (!qDirty && hd != localDelta) { localDelta = hd; ovDirty = true; }
  } else {
    qDirty = false;
    saving = false;
  }
  LEAVE();
  (void)sentQ;
}

static bool syncOnce() {
  if (WiFi.status() != WL_CONNECTED) return false;
  // خذ المدخلات المعلّقة (ونرجعها اذا فشل الارسال)
  int d, b, tx, ty, q = localDelta;
  uint32_t seq;
  bool dirty;
  ENTER();
  d = pendingD; b = pendingBtn; tx = pendingTx; ty = pendingTy;
  pendingD = 0; pendingBtn = 0; pendingTx = -1; pendingTy = -1;
  q = localDelta; seq = qSeq; dirty = qDirty && curMode == M_PRODUCT;
  LEAVE();

  char url[220];
  int n = snprintf(url, sizeof(url), "http://%s:%d/sync?v=%d", PI_HOST, PI_PORT, frameVer);
  if (dirty) n += snprintf(url + n, sizeof(url) - n, "&q=%d", q);
  if (d)     n += snprintf(url + n, sizeof(url) - n, "&d=%d", d);
  if (b)     n += snprintf(url + n, sizeof(url) - n, "&b=%d", b);
  if (tx >= 0) n += snprintf(url + n, sizeof(url) - n, "&tx=%d&ty=%d", tx, ty);

  auto restore = [&]() {
    ENTER();
    pendingD += d;
    if (b && !pendingBtn) pendingBtn = b;
    if (tx >= 0 && pendingTx < 0) { pendingTx = tx; pendingTy = ty; }
    LEAVE();
  };

  uint32_t tStart = millis();
  http.setReuse(true);
  http.setTimeout(4000);
  if (!http.begin(client, url)) { restore(); return false; }
  http.addHeader("X-Token", KNOB_TOKEN);
  const char *keys[] = {"X-Ver", "X-Mode", "X-Delta", "X-Stock", "X-Cnt", "X-Base"};
  http.collectHeaders(keys, 6);
  int code = http.GET();
  uint32_t tGet = millis();
  if (code != 200 && code != 204) {
    String body = (code > 0) ? http.getString() : String("");
    if (body.length() > 160) body = body.substring(0, 160);
    Serial.printf("sync http %d -> %s:%d (my ip %s, rssi %d) %s\n", code, PI_HOST, PI_PORT, WiFi.localIP().toString().c_str(), WiFi.RSSI(), body.c_str());
    http.end();
    restore();
    return false;
  }
  String v = http.header("X-Ver");
  if (code == 204) {
    applyState(q, seq, dirty);
    if (v.length()) frameVer = v.toInt();
    if (millis() - tStart > 300) DBG("[SLOW 204] %lums\n", (unsigned long)(millis() - tStart));
    http.end();
    return true;
  }
  // 200: صورة جديدة
  int len = http.getSize();
  bool okFrame = false;
  if (len > 0 && (size_t)len <= JPG_MAX) {
    WiFiClient *s = http.getStreamPtr();
    size_t got = 0;
    uint32_t t0 = millis();
    while (got < (size_t)len && millis() - t0 < 3000) {
      int av = s->available();
      if (av > 0) got += s->readBytes(jpgBuf + got, min((size_t)av, (size_t)len - got));
      else delay(1);
    }
    if (got == (size_t)len && jpeg.openRAM(jpgBuf, len, drawCB)) {
#if COLOR_SWAP
      jpeg.setPixelType(RGB565_BIG_ENDIAN);
#else
      jpeg.setPixelType(RGB565_LITTLE_ENDIAN);
#endif
      uint32_t tDec0 = millis();
      xSemaphoreTake(fbMux, portMAX_DELAY);
      int decOk = jpeg.decode(0, 0, 0);
      jpeg.close();
      uint32_t tDec1 = millis();
      if (decOk) {
        applyState(q, seq, dirty);
        if (curMode == M_PRODUCT) {            // نحفظ الخلفية النظيفة ثم نرسم الأرقام فوقها قبل رسم الصورة
          copyRegion(clean1, FRAME, decBuf, OX(R1_X), OX(R1_Y), R1_W, R1_H);
          copyRegion(clean2, FRAME, decBuf, OX(R2_X), OX(R2_Y), R2_W, R2_H);
          patchesValid = true;
          composeR1(ov1, clean1, localDelta, saving, curCnt, curBase);
          composeR2(ov2, clean2, curStock, localDelta, saving);
          pasteRegion(decBuf, FRAME, ov1, OX(R1_X), OX(R1_Y), R1_W, R1_H);
          pasteRegion(decBuf, FRAME, ov2, OX(R2_X), OX(R2_Y), R2_W, R2_H);
          ovDirty = false;
        } else {
          patchesValid = false;
        }
        if (needClear) { fillScreen(C_BLACK); needClear = false; frameValid = false; }
        drawDiff();
        okFrame = true;
      }
      xSemaphoreGive(fbMux);
      uint32_t tDone = millis();
      if (v.length()) frameVer = v.toInt();
      DBG("[SYNC] ver=%d %dB decode=%s mode=%d | pi+net=%lums read=%lums decode=%lums draw=%lums total=%lums\n", frameVer, len,
          decOk ? "OK" : "FAILED", curMode, (unsigned long)(tGet - tStart), (unsigned long)(tDec0 - tGet),
          (unsigned long)(tDec1 - tDec0), (unsigned long)(tDone - tDec1), (unsigned long)(tDone - tStart));
    } else {
      Serial.printf("bad frame: got %u of %d\n", (unsigned)got, len);
    }
  }
  http.end();
  if (!okFrame) { restore(); return false; }
  return true;
}

static void netTask(void *) {
  uint32_t lastPoll = 0;
  for (;;) {
    bool input = pendingD || pendingBtn || pendingTx >= 0 || (curMode == M_PRODUCT && qDirty);
    uint32_t now = millis();
    if ((input && now - lastPoll >= 30) || now - lastPoll >= POLL_MS) {
      lastPoll = now;
      if (syncOnce()) {
        lastOk = millis();
        offlineShown = false;
      } else if (millis() - lastOk > 6000) {
        if (!offlineShown) { say("NO SERVER (Pi unreachable)", C_RED); offlineShown = true; frameVer = -1; curMode = M_NONE; }
        if (WiFi.status() != WL_CONNECTED) WiFi.reconnect();
        vTaskDelay(pdMS_TO_TICKS(1000));
      }
    }
    vTaskDelay(pdMS_TO_TICKS(3));
  }
}

// ---------------------------------------------------------------- Arduino
void setup() {
  Serial.begin(115200);
  Serial.println("\n=== GEEKM knob terminal v3.2 (MD80ET 480x480) boot ===");
  DBG("[BOOT] PSRAM %u bytes, free heap %u\n", (unsigned)ESP.getPsramSize(), (unsigned)ESP.getFreeHeap());
  fbMux = xSemaphoreCreateMutex();

  board = new Board();
  board->init();
  bool ok = board->begin();
  Serial.printf("[BOOT] board->begin() = %d\n", ok);
  lcd = board->getLCD();
  tp = board->getTouch();
  if (!lcd) { Serial.println("[BOOT] NO LCD - check libraries\\esp_panel_board_supported_conf.h (MD80ET)"); while (true) delay(1000); }
  auto bl = board->getBacklight();
  if (bl) bl->off();                     // الاضاءة تنفتح بعد ما نرسم الشعار (بدون وميض)
  vsyncSem = xSemaphoreCreateBinary();
  vsyncOk = lcd->attachRefreshFinishCallback(onFrameEnd, nullptr);

#if DEBUG_COLOR_TEST
  {
    const uint16_t cols[] = {C_RED, C_GREEN, C_BLUE, C_WHITE};
    const char *names[] = {"RED", "GREEN", "BLUE", "WHITE"};
    for (int i = 0; i < 4; i++) { DBG("[TEST] screen should be %s now\n", names[i]); fillScreen(cols[i]); delay(700); }
  }
#endif

  jpgBuf = (uint8_t *)ps_malloc(JPG_MAX);
  if (!jpgBuf) jpgBuf = (uint8_t *)malloc(JPG_MAX);
  if (!jpgBuf) { say("NO MEMORY - enable OPI PSRAM", C_RED); while (true) delay(1000); }

  frameBuf = (uint16_t *)ps_malloc((size_t)FRAME * FRAME * 2);
  decBuf = (uint16_t *)ps_malloc((size_t)FRAME * FRAME * 2);
  clean1 = (uint16_t *)ps_malloc((size_t)R1_W * R1_H * 2);
  clean2 = (uint16_t *)ps_malloc((size_t)R2_W * R2_H * 2);
  ov1 = (uint16_t *)ps_malloc((size_t)R1_W * R1_H * 2);
  ov2 = (uint16_t *)ps_malloc((size_t)R2_W * R2_H * 2);
  if (!frameBuf || !decBuf || !clean1 || !clean2 || !ov1 || !ov2) { say("NO MEMORY for frame (OPI PSRAM?)", C_RED); while (true) delay(1000); }
  memset(frameBuf, 0, (size_t)FRAME * FRAME * 2);
  memset(decBuf, 0, (size_t)FRAME * FRAME * 2);
  drawSplash(decBuf);
  frameValid = false;
  drawDiff();                            // الشعار يظهر فوراً
  if (bl) { bl->on(); bl->setBrightness(100); }

  pinMode(PIN_BTN, INPUT_PULLUP);
  pinMode(PIN_ENC_A, INPUT_PULLUP);
  pinMode(PIN_ENC_B, INPUT_PULLUP);
  encState = ((digitalRead(PIN_ENC_A) << 1) | digitalRead(PIN_ENC_B)) & 0x03;
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), encISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_B), encISR, CHANGE);
  DBG("[BOOT] touch=%s\n", tp ? "present" : "MISSING");
  if (tp) xTaskCreatePinnedToCore(touchTask, "touch", 4096, NULL, 1, NULL, 0);

  wifiConnect();
  lastOk = millis();
  xTaskCreatePinnedToCore(netTask, "net", 16384, NULL, 1, NULL, 0);
}

void loop() {
  updateButton();
  updateTouch();
  int d = takeEncoder();
  if (d) { onTurn(d); DBG("[ENC] turn %+d -> delta=%d mode=%d\n", d, localDelta, (int)curMode); }
  if (saving && millis() - savingT > SAVE_FEEDBACK_MS) { saving = false; ovDirty = true; }
  if (ovDirty) { ovDirty = false; overlayRedraw(); }
#if DEBUG_SERIAL
  {
    static uint32_t hb = 0;
    uint32_t t = millis();
    if (t - hb > 5000) {
      hb = t;
      DBG("[ALIVE] wifi=%d rssi=%d frameVer=%d mode=%d delta=%d lastOkAgo=%lus heap=%u | BTN=%d A=%d B=%d\n",
          WiFi.status() == WL_CONNECTED, WiFi.RSSI(), frameVer, (int)curMode, (int)localDelta, (unsigned long)((t - lastOk) / 1000),
          (unsigned)ESP.getFreeHeap(), digitalRead(PIN_BTN), digitalRead(PIN_ENC_A), digitalRead(PIN_ENC_B));
    }
  }
#endif
  delay(1);
}
